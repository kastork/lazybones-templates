# Starter project with JavaFX, TornadoFX

[TornadoFX](https://github.com/edvin/tornadofx)
[Kotlin](https://kotlinlang.org/)
[JavaFX](http://www.oracle.com/technetwork/java/javase/overview/javafx-overview-2158620.html)
